/** Automatically generated file. DO NOT MODIFY */
package com.nus.gems;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}